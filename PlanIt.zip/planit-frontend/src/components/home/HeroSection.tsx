import { Search, MapPin, Calendar, Users } from 'lucide-react'

function HeroSection() {
    return (
        <section className="min-h-screen flex flex-col items-center justify-center px-8 pt-16 pb-20 bg-gradient-to-b from-[#EBF5FC] via-[#F0F8FD] to-white relative overflow-hidden">

            {/* Background glow */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[600px] bg-[radial-gradient(ellipse,rgba(109,182,227,0.15)_0%,transparent_65%)] pointer-events-none" />

            {/* Badge */}
            <div className="flex items-center gap-2 bg-[#EBF5FC] border border-[#6DB6E3]/30 text-[#4A9DD4] text-xs font-bold px-4 py-1.5 rounded-full mb-7 tracking-wider">
                ✦ Platform Event Organizer #1 di Indonesia
            </div>

            {/* Title */}
            <h1 className="font-black text-6xl text-gray-900 text-center leading-tight mb-2" style={{ fontFamily: 'Nunito, sans-serif' }}>
                Find your perfect event,
            </h1>
            <h1 className="font-black text-6xl text-[#6DB6E3] text-center leading-tight mb-6" style={{ fontFamily: 'Nunito, sans-serif' }}>
                all in one place.
            </h1>

            {/* Subtitle */}
            <p className="text-gray-500 text-lg text-center max-w-md mb-12 leading-relaxed">
                Book venues & event organizers easily and securely — all in one platform.
            </p>

            {/* Search Bar */}
            <div className="flex items-center bg-white border border-gray-200 rounded-2xl shadow-xl max-w-4xl w-full">
                <div className="flex items-center gap-3 px-6 py-5 flex-1 border-r border-gray-200 cursor-pointer hover:bg-gray-50 rounded-l-2xl transition-all">
                    <Search size={18} className="text-[#6DB6E3] flex-shrink-0" />
                    <div>
                        <div className="text-xs font-bold text-gray-800 whitespace-nowrap">What</div>
                        <div className="text-sm text-gray-400 whitespace-nowrap">Venue or Event Org.</div>
                    </div>
                </div>
                <div className="flex items-center gap-3 px-6 py-5 flex-1 border-r border-gray-200 cursor-pointer hover:bg-gray-50 transition-all">
                    <MapPin size={18} className="text-[#6DB6E3] flex-shrink-0" />
                    <div>
                        <div className="text-xs font-bold text-gray-800 whitespace-nowrap">Where</div>
                        <div className="text-sm text-gray-400 whitespace-nowrap">City or location</div>
                    </div>
                </div>
                <div className="flex items-center gap-3 px-6 py-5 flex-1 border-r border-gray-200 cursor-pointer hover:bg-gray-50 transition-all">
                    <Calendar size={18} className="text-[#6DB6E3] flex-shrink-0" />
                    <div>
                        <div className="text-xs font-bold text-gray-800 whitespace-nowrap">When</div>
                        <div className="text-sm text-gray-400 whitespace-nowrap">Add date</div>
                    </div>
                </div>
                <div className="flex items-center gap-3 px-6 py-5 flex-1 cursor-pointer hover:bg-gray-50 transition-all">
                    <Users size={18} className="text-[#6DB6E3] flex-shrink-0" />
                    <div>
                        <div className="text-xs font-bold text-gray-800 whitespace-nowrap">Guests</div>
                        <div className="text-sm text-gray-400 whitespace-nowrap">Add guests</div>
                    </div>
                </div>
                <div className="p-3">
                    <button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-6 py-4 rounded-xl transition-all whitespace-nowrap">
                        <Search size={16} />
                        Search
                    </button>
                </div>
            </div>

            {/* Stats */}
            <div className="flex items-center mt-14 bg-white border border-gray-100 rounded-2xl shadow-sm overflow-hidden">
                {[
                    { num: '500+', label: 'Event Organizers' },
                    { num: '12K+', label: 'Successful Events' },
                    { num: '4.9★', label: 'Average Rating' },
                    { num: '98%', label: 'Satisfaction Rate' },
                ].map((stat, i) => (
                    <div key={i} className={`px-10 py-5 text-center ${i < 3 ? 'border-r border-gray-100' : ''}`}>
                        <div className="font-black text-2xl text-gray-900" style={{ fontFamily: 'Nunito, sans-serif' }}>{stat.num}</div>
                        <div className="text-sm text-gray-500 mt-1">{stat.label}</div>
                    </div>
                ))}
            </div>

        </section>
    )
}

export default HeroSection