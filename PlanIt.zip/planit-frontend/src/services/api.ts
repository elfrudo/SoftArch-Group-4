import axios from 'axios'

const api = axios.create({
  baseURL: 'http://localhost:3000',
  headers: { 'Content-Type': 'application/json' },
})

// Auto attach token ke setiap request
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('planit_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

export default api